<?php
$page_title = "Tableau de bord Vendeur";
require_once '../config/config.php';
require_once '../config/database.php';
requireRole(ROLE_VENDEUR);

$conn = getDBConnection();
$vendeur_id = $_SESSION['user_id'];

// Statistiques du vendeur
$stats = [];

// Nombre de produits du vendeur
$result = $conn->query("SELECT COUNT(*) as total FROM products WHERE vendeur_id = $vendeur_id");
$stats['total_products'] = $result->fetch_assoc()['total'];

// Produits en stock faible
$result = $conn->query("SELECT COUNT(*) as total FROM products WHERE vendeur_id = $vendeur_id AND stock <= stock_minimum AND statut = 'actif'");
$stats['low_stock'] = $result->fetch_assoc()['total'];

// Commandes du vendeur
$result = $conn->query("SELECT COUNT(*) as total FROM orders o 
                        JOIN order_items oi ON o.id = oi.order_id 
                        JOIN products p ON oi.product_id = p.id 
                        WHERE p.vendeur_id = $vendeur_id");
$stats['total_orders'] = $result->fetch_assoc()['total'];

// Chiffre d'affaires du mois
$result = $conn->query("SELECT SUM(oi.prix_total) as total FROM orders o 
                        JOIN order_items oi ON o.id = oi.order_id 
                        JOIN products p ON oi.product_id = p.id 
                        WHERE p.vendeur_id = $vendeur_id 
                        AND MONTH(o.created_at) = MONTH(CURRENT_DATE()) 
                        AND YEAR(o.created_at) = YEAR(CURRENT_DATE()) 
                        AND o.statut != 'annulee'");
$stats['monthly_revenue'] = $result->fetch_assoc()['total'] ?? 0;

// Bénéfice du mois
$result = $conn->query("SELECT SUM(oi.benefice) as total FROM orders o 
                        JOIN order_items oi ON o.id = oi.order_id 
                        JOIN products p ON oi.product_id = p.id 
                        WHERE p.vendeur_id = $vendeur_id 
                        AND MONTH(o.created_at) = MONTH(CURRENT_DATE()) 
                        AND YEAR(o.created_at) = YEAR(CURRENT_DATE()) 
                        AND o.statut != 'annulee'");
$stats['monthly_profit'] = $result->fetch_assoc()['total'] ?? 0;

// Commandes récentes du vendeur
$recent_orders = $conn->query("SELECT DISTINCT o.*, u.nom, u.prenom 
                                FROM orders o 
                                JOIN order_items oi ON o.id = oi.order_id 
                                JOIN products p ON oi.product_id = p.id 
                                JOIN users u ON o.client_id = u.id 
                                WHERE p.vendeur_id = $vendeur_id 
                                ORDER BY o.created_at DESC 
                                LIMIT 10");

// Produits en stock faible
$low_stock_products = $conn->query("SELECT * FROM products WHERE vendeur_id = $vendeur_id AND stock <= stock_minimum AND statut = 'actif' ORDER BY stock ASC LIMIT 10");

require_once '../includes/header.php';
?>

<div class="container">
    <h1 class="section-title">Tableau de bord Vendeur</h1>
    
    <div class="dashboard-stats">
        <div class="stat-card">
            <h3>Mes Produits</h3>
            <div class="stat-value"><?php echo $stats['total_products']; ?></div>
            <p style="color: var(--accent-color); margin-top: 0.5rem;">
                <?php echo $stats['low_stock']; ?> en stock faible
            </p>
        </div>
        
        <div class="stat-card success">
            <h3>Chiffre d'affaires (Mois)</h3>
            <div class="stat-value"><?php echo formatPrice($stats['monthly_revenue']); ?></div>
        </div>
        
        <div class="stat-card success">
            <h3>Bénéfice (Mois)</h3>
            <div class="stat-value"><?php echo formatPrice($stats['monthly_profit']); ?></div>
        </div>
        
        <div class="stat-card">
            <h3>Commandes</h3>
            <div class="stat-value"><?php echo $stats['total_orders']; ?></div>
        </div>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-top: 3rem;">
        <div class="card">
            <div class="card-header">
                <h2>Commandes récentes</h2>
            </div>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>N° Commande</th>
                            <th>Client</th>
                            <th>Total</th>
                            <th>Statut</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($order = $recent_orders->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($order['numero_commande']); ?></td>
                                <td><?php echo htmlspecialchars($order['nom'] . ' ' . $order['prenom']); ?></td>
                                <td><?php echo formatPrice($order['total']); ?></td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $order['statut'] == 'livree' ? 'success' : 
                                            ($order['statut'] == 'en_attente' ? 'warning' : '');
                                    ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $order['statut'])); ?>
                                    </span>
                                </td>
                                <td><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>Produits en stock faible</h2>
            </div>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Produit</th>
                            <th>Stock</th>
                            <th>Stock min</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($product = $low_stock_products->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($product['nom']); ?></td>
                                <td style="color: var(--accent-color); font-weight: bold;"><?php echo $product['stock']; ?></td>
                                <td><?php echo $product['stock_minimum']; ?></td>
                                <td>
                                    <a href="products.php?action=edit&id=<?php echo $product['id']; ?>" class="btn btn-warning" style="padding: 0.5rem 1rem; font-size: 0.9rem;">Réapprovisionner</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div style="margin-top: 2rem; text-align: center;">
        <a href="products.php" class="btn btn-primary">Gérer mes produits</a>
        <a href="orders.php" class="btn btn-primary">Voir mes commandes</a>
        <a href="statistics.php" class="btn btn-secondary">Mes statistiques</a>
    </div>
</div>

<?php
$conn->close();
require_once '../includes/footer.php';
?>

