<?php
// Configuration générale du site
session_start();

// Configuration de base
define('SITE_NAME', 'Diexo E-commerce');
define('SITE_URL', 'http://localhost/diexo');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');

// Configuration WhatsApp
define('WHATSAPP_NUMBER', '221XXXXXXXX'); // Remplacer par votre numéro WhatsApp
define('WHATSAPP_API_URL', 'https://api.whatsapp.com/send');

// Configuration des rôles
define('ROLE_ADMIN', 'admin');
define('ROLE_VENDEUR', 'vendeur');
define('ROLE_CLIENT', 'client');

// Fonction pour vérifier l'authentification
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Fonction pour vérifier le rôle
function hasRole($role) {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
}

// Fonction pour rediriger si non connecté
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . SITE_URL . '/auth/login.php');
        exit();
    }
}

// Fonction pour rediriger selon le rôle
function requireRole($role) {
    requireLogin();
    if (!hasRole($role)) {
        header('Location: ' . SITE_URL . '/index.php');
        exit();
    }
}

// Fonction pour formater le prix
function formatPrice($price) {
    return number_format($price, 2, ',', ' ') . ' FCFA';
}

// Fonction pour sécuriser les données
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}
?>

