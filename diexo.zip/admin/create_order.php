<?php
// Script pour créer une commande manuellement (depuis WhatsApp ou autre)
require_once '../config/config.php';
require_once '../config/database.php';
requireRole(ROLE_ADMIN);

$conn = getDBConnection();
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_order') {
    $client_id = (int)$_POST['client_id'];
    $products = json_decode($_POST['products'], true);
    $adresse_livraison = sanitize($_POST['adresse_livraison'] ?? '');
    $telephone_livraison = sanitize($_POST['telephone_livraison'] ?? '');
    $notes = sanitize($_POST['notes'] ?? '');
    $mode_paiement = sanitize($_POST['mode_paiement'] ?? 'whatsapp');
    
    if (!empty($products) && is_array($products)) {
        $conn->begin_transaction();
        
        try {
            // Calculer le total
            $total = 0;
            $order_items = [];
            
            foreach ($products as $product_data) {
                $product_id = (int)$product_data['id'];
                $quantite = (int)$product_data['quantity'];
                
                // Récupérer le produit
                $product_query = $conn->prepare("SELECT * FROM products WHERE id = ? AND statut = 'actif'");
                $product_query->bind_param("i", $product_id);
                $product_query->execute();
                $product = $product_query->get_result()->fetch_assoc();
                
                if ($product && $product['stock'] >= $quantite) {
                    $prix_unitaire = $product['prix_vente'];
                    $prix_total = $prix_unitaire * $quantite;
                    $benefice = ($prix_unitaire - $product['prix_achat']) * $quantite;
                    
                    $total += $prix_total;
                    
                    $order_items[] = [
                        'product_id' => $product_id,
                        'quantite' => $quantite,
                        'prix_unitaire' => $prix_unitaire,
                        'prix_total' => $prix_total,
                        'benefice' => $benefice
                    ];
                }
            }
            
            if (empty($order_items)) {
                throw new Exception('Aucun produit valide dans la commande.');
            }
            
            // Générer un numéro de commande unique
            $numero_commande = 'CMD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
            
            // Créer la commande
            $order_stmt = $conn->prepare("INSERT INTO orders (client_id, numero_commande, total, mode_paiement, adresse_livraison, telephone_livraison, notes, statut) VALUES (?, ?, ?, ?, ?, ?, ?, 'en_attente')");
            $order_stmt->bind_param("isddsss", $client_id, $numero_commande, $total, $mode_paiement, $adresse_livraison, $telephone_livraison, $notes);
            $order_stmt->execute();
            $order_id = $conn->insert_id;
            $order_stmt->close();
            
            // Créer les items de commande et mettre à jour le stock
            foreach ($order_items as $item) {
                $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantite, prix_unitaire, prix_total, benefice) VALUES (?, ?, ?, ?, ?, ?)");
                $item_stmt->bind_param("iiiddd", $order_id, $item['product_id'], $item['quantite'], $item['prix_unitaire'], $item['prix_total'], $item['benefice']);
                $item_stmt->execute();
                $item_stmt->close();
                
                // Mettre à jour le stock
                $update_stock = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                $update_stock->bind_param("ii", $item['quantite'], $item['product_id']);
                $update_stock->execute();
                $update_stock->close();
            }
            
            // Créer une dette si le paiement n'est pas complet
            if ($mode_paiement === 'whatsapp' || isset($_POST['create_debt'])) {
                $debt_stmt = $conn->prepare("INSERT INTO client_debts (client_id, order_id, montant_total, montant_restant, statut) VALUES (?, ?, ?, ?, 'en_cours')");
                $debt_stmt->bind_param("iidd", $client_id, $order_id, $total, $total);
                $debt_stmt->execute();
                $debt_stmt->close();
            }
            
            $conn->commit();
            $message = 'Commande créée avec succès. Numéro: ' . $numero_commande;
            $message_type = 'success';
            
        } catch (Exception $e) {
            $conn->rollback();
            $message = 'Erreur: ' . $e->getMessage();
            $message_type = 'danger';
        }
    } else {
        $message = 'Veuillez sélectionner au moins un produit.';
        $message_type = 'danger';
    }
}

// Récupérer les clients
$clients = $conn->query("SELECT * FROM users WHERE role = 'client' ORDER BY nom, prenom");

// Récupérer les produits actifs
$products_list = $conn->query("SELECT * FROM products WHERE statut = 'actif' AND stock > 0 ORDER BY nom");

$page_title = "Créer une Commande";
require_once '../includes/header.php';
?>

<div class="container" style="max-width: 1000px;">
    <h1>Créer une Commande</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type === 'success' ? 'success' : 'danger'; ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    
    <div class="card">
        <form method="POST" id="orderForm">
            <input type="hidden" name="action" value="create_order">
            
            <div class="form-group">
                <label for="client_id">Client *</label>
                <select id="client_id" name="client_id" class="form-control" required>
                    <option value="">Sélectionner un client</option>
                    <?php while ($client = $clients->fetch_assoc()): ?>
                        <option value="<?php echo $client['id']; ?>">
                            <?php echo htmlspecialchars($client['nom'] . ' ' . $client['prenom'] . ' (' . $client['email'] . ')'); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Produits *</label>
                <div id="productsList" style="border: 1px solid var(--border-color); padding: 1rem; border-radius: 5px; max-height: 400px; overflow-y: auto;">
                    <?php while ($product = $products_list->fetch_assoc()): ?>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; border-bottom: 1px solid var(--border-color);">
                            <div>
                                <strong><?php echo htmlspecialchars($product['nom']); ?></strong>
                                <br>
                                <small>Stock: <?php echo $product['stock']; ?> | Prix: <?php echo formatPrice($product['prix_vente']); ?></small>
                            </div>
                            <div style="display: flex; align-items: center; gap: 1rem;">
                                <input type="number" 
                                       class="product-quantity" 
                                       data-product-id="<?php echo $product['id']; ?>"
                                       data-price="<?php echo $product['prix_vente']; ?>"
                                       min="0" 
                                       max="<?php echo $product['stock']; ?>" 
                                       value="0" 
                                       style="width: 80px; padding: 0.5rem;">
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
            
            <div class="form-group">
                <label for="adresse_livraison">Adresse de livraison</label>
                <textarea id="adresse_livraison" name="adresse_livraison" class="form-control" rows="3"></textarea>
            </div>
            
            <div class="form-group">
                <label for="telephone_livraison">Téléphone de livraison</label>
                <input type="tel" id="telephone_livraison" name="telephone_livraison" class="form-control">
            </div>
            
            <div class="form-group">
                <label for="mode_paiement">Mode de paiement</label>
                <select id="mode_paiement" name="mode_paiement" class="form-control">
                    <option value="whatsapp">WhatsApp</option>
                    <option value="espece">Espèce</option>
                    <option value="mobile_money">Mobile Money</option>
                    <option value="carte">Carte</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="notes">Notes</label>
                <textarea id="notes" name="notes" class="form-control" rows="3"></textarea>
            </div>
            
            <div id="totalDisplay" style="font-size: 1.5rem; font-weight: bold; color: var(--accent-color); margin: 1rem 0; text-align: right;">
                Total: 0 FCFA
            </div>
            
            <input type="hidden" name="products" id="productsInput">
            
            <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                <button type="submit" class="btn btn-primary">Créer la commande</button>
                <a href="orders.php" class="btn btn-secondary">Annuler</a>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const quantities = document.querySelectorAll('.product-quantity');
    const productsInput = document.getElementById('productsInput');
    const totalDisplay = document.getElementById('totalDisplay');
    const form = document.getElementById('orderForm');
    
    function updateTotal() {
        let total = 0;
        const selectedProducts = [];
        
        quantities.forEach(input => {
            const qty = parseInt(input.value) || 0;
            if (qty > 0) {
                const productId = input.dataset.productId;
                const price = parseFloat(input.dataset.price);
                total += price * qty;
                
                selectedProducts.push({
                    id: productId,
                    quantity: qty
                });
            }
        });
        
        totalDisplay.textContent = 'Total: ' + total.toLocaleString('fr-FR') + ' FCFA';
        productsInput.value = JSON.stringify(selectedProducts);
    }
    
    quantities.forEach(input => {
        input.addEventListener('change', updateTotal);
    });
    
    form.addEventListener('submit', function(e) {
        const products = JSON.parse(productsInput.value);
        if (products.length === 0) {
            e.preventDefault();
            alert('Veuillez sélectionner au moins un produit.');
            return false;
        }
    });
    
    updateTotal();
});
</script>

<?php
$conn->close();
require_once '../includes/footer.php';
?>

