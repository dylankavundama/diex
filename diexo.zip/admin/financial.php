<?php
$page_title = "Gestion Financière";
require_once '../config/config.php';
require_once '../config/database.php';
requireRole(ROLE_ADMIN);

$conn = getDBConnection();
$message = '';
$message_type = '';

// Traitement du paiement de dette
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'pay_debt') {
    $debt_id = (int)$_POST['debt_id'];
    $montant = (float)$_POST['montant'];
    $mode_paiement = sanitize($_POST['mode_paiement']);
    
    // Récupérer la dette
    $debt_query = $conn->prepare("SELECT * FROM client_debts WHERE id = ?");
    $debt_query->bind_param("i", $debt_id);
    $debt_query->execute();
    $debt = $debt_query->get_result()->fetch_assoc();
    
    if ($debt && $montant > 0 && $montant <= $debt['montant_restant']) {
        $new_paid = $debt['montant_paye'] + $montant;
        $new_remaining = $debt['montant_restant'] - $montant;
        $new_status = $new_remaining <= 0 ? 'paye' : ($new_paid > 0 ? 'partiel' : 'en_cours');
        
        // Mettre à jour la dette
        $update_debt = $conn->prepare("UPDATE client_debts SET montant_paye = ?, montant_restant = ?, statut = ? WHERE id = ?");
        $update_debt->bind_param("ddss", $new_paid, $new_remaining, $new_status, $debt_id);
        $update_debt->execute();
        
        // Enregistrer le paiement
        $insert_payment = $conn->prepare("INSERT INTO payments (order_id, client_id, montant, type_paiement, mode_paiement, description) VALUES (?, ?, ?, 'entree', ?, ?)");
        $description = "Paiement dette client - Commande #" . ($debt['order_id'] ?? 'N/A');
        $insert_payment->bind_param("iidss", $debt['order_id'], $debt['client_id'], $montant, $mode_paiement, $description);
        $insert_payment->execute();
        
        $message = 'Paiement enregistré avec succès.';
        $message_type = 'success';
    } else {
        $message = 'Montant invalide.';
        $message_type = 'danger';
    }
}

// Statistiques financières
$stats = [];

// Recettes du mois
$result = $conn->query("SELECT SUM(montant) as total FROM payments 
                        WHERE type_paiement = 'entree' 
                        AND MONTH(created_at) = MONTH(CURRENT_DATE()) 
                        AND YEAR(created_at) = YEAR(CURRENT_DATE()) 
                        AND statut = 'valide'");
$stats['monthly_income'] = $result->fetch_assoc()['total'] ?? 0;

// Dépenses du mois
$result = $conn->query("SELECT SUM(montant) as total FROM payments 
                        WHERE type_paiement = 'sortie' 
                        AND MONTH(created_at) = MONTH(CURRENT_DATE()) 
                        AND YEAR(created_at) = YEAR(CURRENT_DATE()) 
                        AND statut = 'valide'");
$stats['monthly_expenses'] = $result->fetch_assoc()['total'] ?? 0;

// Dettes totales
$result = $conn->query("SELECT SUM(montant_restant) as total FROM client_debts WHERE statut != 'paye'");
$stats['total_debts'] = $result->fetch_assoc()['total'] ?? 0;

// Solde de caisse (approximatif)
$stats['cash_balance'] = $stats['monthly_income'] - $stats['monthly_expenses'];

// Dettes des clients
$debts = $conn->query("SELECT cd.*, u.nom, u.prenom, u.telephone, o.numero_commande 
                       FROM client_debts cd 
                       JOIN users u ON cd.client_id = u.id 
                       LEFT JOIN orders o ON cd.order_id = o.id 
                       WHERE cd.statut != 'paye' 
                       ORDER BY cd.created_at DESC");

// Paiements récents
$recent_payments = $conn->query("SELECT p.*, u.nom, u.prenom 
                                 FROM payments p 
                                 JOIN users u ON p.client_id = u.id 
                                 ORDER BY p.created_at DESC 
                                 LIMIT 20");

require_once '../includes/header.php';
?>

<div class="container">
    <h1 class="section-title">Gestion Financière</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type === 'success' ? 'success' : 'danger'; ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    
    <div class="dashboard-stats">
        <div class="stat-card success">
            <h3>Recettes (Mois)</h3>
            <div class="stat-value"><?php echo formatPrice($stats['monthly_income']); ?></div>
        </div>
        
        <div class="stat-card danger">
            <h3>Dépenses (Mois)</h3>
            <div class="stat-value"><?php echo formatPrice($stats['monthly_expenses']); ?></div>
        </div>
        
        <div class="stat-card <?php echo $stats['cash_balance'] >= 0 ? 'success' : 'danger'; ?>">
            <h3>Solde (Mois)</h3>
            <div class="stat-value"><?php echo formatPrice($stats['cash_balance']); ?></div>
        </div>
        
        <div class="stat-card warning">
            <h3>Dettes totales</h3>
            <div class="stat-value"><?php echo formatPrice($stats['total_debts']); ?></div>
        </div>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-top: 3rem;">
        <div class="card">
            <div class="card-header">
                <h2>Dettes des clients</h2>
            </div>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Client</th>
                            <th>Commande</th>
                            <th>Montant total</th>
                            <th>Payé</th>
                            <th>Restant</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($debt = $debts->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div><?php echo htmlspecialchars($debt['nom'] . ' ' . $debt['prenom']); ?></div>
                                    <small><?php echo htmlspecialchars($debt['telephone']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($debt['numero_commande'] ?? 'N/A'); ?></td>
                                <td><?php echo formatPrice($debt['montant_total']); ?></td>
                                <td><?php echo formatPrice($debt['montant_paye']); ?></td>
                                <td style="color: var(--accent-color); font-weight: bold;"><?php echo formatPrice($debt['montant_restant']); ?></td>
                                <td>
                                    <button onclick="openPaymentModal(<?php echo $debt['id']; ?>, <?php echo $debt['montant_restant']; ?>)" 
                                            class="btn btn-success" 
                                            style="padding: 0.5rem 1rem; font-size: 0.9rem;">
                                        Payer
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>Paiements récents</h2>
            </div>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Client</th>
                            <th>Montant</th>
                            <th>Type</th>
                            <th>Mode</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($payment = $recent_payments->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo date('d/m/Y H:i', strtotime($payment['created_at'])); ?></td>
                                <td><?php echo htmlspecialchars($payment['nom'] . ' ' . $payment['prenom']); ?></td>
                                <td style="color: <?php echo $payment['type_paiement'] === 'entree' ? 'var(--success-color)' : 'var(--accent-color)'; ?>; font-weight: bold;">
                                    <?php echo $payment['type_paiement'] === 'entree' ? '+' : '-'; ?><?php echo formatPrice($payment['montant']); ?>
                                </td>
                                <td><?php echo ucfirst($payment['type_paiement']); ?></td>
                                <td><?php echo ucfirst(str_replace('_', ' ', $payment['mode_paiement'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal de paiement -->
<div id="paymentModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center;">
    <div class="card" style="max-width: 500px; margin: 2rem; position: relative;">
        <button onclick="closePaymentModal()" style="position: absolute; top: 1rem; right: 1rem; background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
        <h2>Enregistrer un paiement</h2>
        <form method="POST" action="">
            <input type="hidden" name="action" value="pay_debt">
            <input type="hidden" name="debt_id" id="debt_id">
            
            <div class="form-group">
                <label>Montant restant</label>
                <input type="text" id="remaining_amount" class="form-control" readonly>
            </div>
            
            <div class="form-group">
                <label for="montant">Montant à payer *</label>
                <input type="number" id="montant" name="montant" class="form-control" step="0.01" min="0" required>
            </div>
            
            <div class="form-group">
                <label for="mode_paiement">Mode de paiement *</label>
                <select id="mode_paiement" name="mode_paiement" class="form-control" required>
                    <option value="espece">Espèce</option>
                    <option value="mobile_money">Mobile Money</option>
                    <option value="carte">Carte</option>
                    <option value="virement">Virement</option>
                </select>
            </div>
            
            <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                <button type="submit" class="btn btn-success">Enregistrer</button>
                <button type="button" onclick="closePaymentModal()" class="btn btn-secondary">Annuler</button>
            </div>
        </form>
    </div>
</div>

<script>
function openPaymentModal(debtId, remainingAmount) {
    document.getElementById('debt_id').value = debtId;
    document.getElementById('remaining_amount').value = remainingAmount.toLocaleString('fr-FR') + ' FCFA';
    document.getElementById('montant').max = remainingAmount;
    document.getElementById('paymentModal').style.display = 'flex';
}

function closePaymentModal() {
    document.getElementById('paymentModal').style.display = 'none';
}
</script>

<?php
$conn->close();
require_once '../includes/footer.php';
?>

