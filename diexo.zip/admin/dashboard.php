<?php
$page_title = "Tableau de bord Admin";
require_once '../config/config.php';
require_once '../config/database.php';
requireRole(ROLE_ADMIN);

$conn = getDBConnection();

// Statistiques générales
$stats = [];

// Nombre total de produits
$result = $conn->query("SELECT COUNT(*) as total FROM products");
$stats['total_products'] = $result->fetch_assoc()['total'];

// Nombre de produits en stock faible
$result = $conn->query("SELECT COUNT(*) as total FROM products WHERE stock <= stock_minimum AND statut = 'actif'");
$stats['low_stock'] = $result->fetch_assoc()['total'];

// Nombre total de commandes
$result = $conn->query("SELECT COUNT(*) as total FROM orders");
$stats['total_orders'] = $result->fetch_assoc()['total'];

// Commandes en attente
$result = $conn->query("SELECT COUNT(*) as total FROM orders WHERE statut = 'en_attente'");
$stats['pending_orders'] = $result->fetch_assoc()['total'];

// Nombre total de clients
$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'client'");
$stats['total_clients'] = $result->fetch_assoc()['total'];

// Nombre de vendeurs
$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'vendeur'");
$stats['total_vendeurs'] = $result->fetch_assoc()['total'];

// Chiffre d'affaires du mois
$result = $conn->query("SELECT SUM(total) as total FROM orders WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE()) AND statut != 'annulee'");
$stats['monthly_revenue'] = $result->fetch_assoc()['total'] ?? 0;

// Bénéfice du mois
$result = $conn->query("SELECT SUM(benefice) as total FROM order_items oi 
                        JOIN orders o ON oi.order_id = o.id 
                        WHERE MONTH(o.created_at) = MONTH(CURRENT_DATE()) 
                        AND YEAR(o.created_at) = YEAR(CURRENT_DATE()) 
                        AND o.statut != 'annulee'");
$stats['monthly_profit'] = $result->fetch_assoc()['total'] ?? 0;

// Dettes totales
$result = $conn->query("SELECT SUM(montant_restant) as total FROM client_debts WHERE statut != 'paye'");
$stats['total_debts'] = $result->fetch_assoc()['total'] ?? 0;

// Commandes récentes
$recent_orders = $conn->query("SELECT o.*, u.nom, u.prenom 
                                FROM orders o 
                                JOIN users u ON o.client_id = u.id 
                                ORDER BY o.created_at DESC 
                                LIMIT 10");

// Produits en stock faible
$low_stock_products = $conn->query("SELECT * FROM products WHERE stock <= stock_minimum AND statut = 'actif' ORDER BY stock ASC LIMIT 10");

require_once '../includes/header.php';
?>

<div class="container">
    <h1 class="section-title">Tableau de bord Administrateur</h1>
    
    <div class="dashboard-stats">
        <div class="stat-card">
            <h3>Produits</h3>
            <div class="stat-value"><?php echo $stats['total_products']; ?></div>
            <p style="color: var(--accent-color); margin-top: 0.5rem;">
                <?php echo $stats['low_stock']; ?> en stock faible
            </p>
        </div>
        
        <div class="stat-card success">
            <h3>Chiffre d'affaires (Mois)</h3>
            <div class="stat-value"><?php echo formatPrice($stats['monthly_revenue']); ?></div>
        </div>
        
        <div class="stat-card success">
            <h3>Bénéfice (Mois)</h3>
            <div class="stat-value"><?php echo formatPrice($stats['monthly_profit']); ?></div>
        </div>
        
        <div class="stat-card">
            <h3>Commandes</h3>
            <div class="stat-value"><?php echo $stats['total_orders']; ?></div>
            <p style="color: var(--warning-color); margin-top: 0.5rem;">
                <?php echo $stats['pending_orders']; ?> en attente
            </p>
        </div>
        
        <div class="stat-card">
            <h3>Clients</h3>
            <div class="stat-value"><?php echo $stats['total_clients']; ?></div>
        </div>
        
        <div class="stat-card warning">
            <h3>Dettes totales</h3>
            <div class="stat-value"><?php echo formatPrice($stats['total_debts']); ?></div>
        </div>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-top: 3rem;">
        <div class="card">
            <div class="card-header">
                <h2>Commandes récentes</h2>
            </div>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>N° Commande</th>
                            <th>Client</th>
                            <th>Total</th>
                            <th>Statut</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($order = $recent_orders->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($order['numero_commande']); ?></td>
                                <td><?php echo htmlspecialchars($order['nom'] . ' ' . $order['prenom']); ?></td>
                                <td><?php echo formatPrice($order['total']); ?></td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $order['statut'] == 'livree' ? 'success' : 
                                            ($order['statut'] == 'en_attente' ? 'warning' : '');
                                    ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $order['statut'])); ?>
                                    </span>
                                </td>
                                <td><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></td>
                                <td>
                                    <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-primary" style="padding: 0.5rem 1rem; font-size: 0.9rem;">Voir</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>Produits en stock faible</h2>
            </div>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Produit</th>
                            <th>Stock</th>
                            <th>Stock min</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($product = $low_stock_products->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($product['nom']); ?></td>
                                <td style="color: var(--accent-color); font-weight: bold;"><?php echo $product['stock']; ?></td>
                                <td><?php echo $product['stock_minimum']; ?></td>
                                <td>
                                    <a href="products.php?action=edit&id=<?php echo $product['id']; ?>" class="btn btn-warning" style="padding: 0.5rem 1rem; font-size: 0.9rem;">Réapprovisionner</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div style="margin-top: 2rem; text-align: center;">
        <a href="products.php" class="btn btn-primary">Gérer les produits</a>
        <a href="orders.php" class="btn btn-primary">Voir toutes les commandes</a>
        <a href="reports.php" class="btn btn-secondary">Rapports</a>
        <a href="users.php" class="btn btn-secondary">Gérer les utilisateurs</a>
        <a href="financial.php" class="btn btn-secondary">Finances</a>
    </div>
</div>

<?php
$conn->close();
require_once '../includes/footer.php';
?>

