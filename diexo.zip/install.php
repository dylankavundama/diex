<?php
/**
 * Script d'installation automatique
 * Exécutez ce fichier une seule fois pour configurer la base de données
 */

// Configuration
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'diexo_ecommerce';

$errors = [];
$success = [];

// Vérifier les extensions PHP
if (!extension_loaded('mysqli')) {
    $errors[] = 'Extension mysqli n\'est pas activée.';
}

if (!extension_loaded('pdo')) {
    $errors[] = 'Extension PDO n\'est pas activée.';
}

// Connexion à MySQL
try {
    $conn = new mysqli($db_host, $db_user, $db_pass);
    
    if ($conn->connect_error) {
        $errors[] = 'Impossible de se connecter à MySQL: ' . $conn->connect_error;
    } else {
        $success[] = 'Connexion à MySQL réussie.';
        
        // Créer la base de données si elle n'existe pas
        $create_db = "CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
        if ($conn->query($create_db)) {
            $success[] = "Base de données '$db_name' créée ou déjà existante.";
        } else {
            $errors[] = 'Erreur lors de la création de la base de données: ' . $conn->error;
        }
        
        // Sélectionner la base de données
        $conn->select_db($db_name);
        
        // Lire et exécuter le schéma SQL
        $schema_file = __DIR__ . '/database/schema.sql';
        if (file_exists($schema_file)) {
            $sql = file_get_contents($schema_file);
            
            // Diviser les requêtes
            $queries = array_filter(array_map('trim', explode(';', $sql)));
            
            foreach ($queries as $query) {
                if (!empty($query) && !preg_match('/^--/', $query)) {
                    if (!$conn->query($query)) {
                        // Ignorer les erreurs de tables existantes
                        if (strpos($conn->error, 'already exists') === false) {
                            $errors[] = 'Erreur SQL: ' . $conn->error . ' (Requête: ' . substr($query, 0, 50) . '...)';
                        }
                    }
                }
            }
            
            $success[] = 'Schéma de base de données importé.';
        } else {
            $errors[] = 'Fichier schema.sql introuvable.';
        }
        
        // Vérifier les tables créées
        $tables = ['users', 'categories', 'products', 'orders', 'order_items', 'payments', 'client_debts'];
        $tables_ok = true;
        foreach ($tables as $table) {
            $result = $conn->query("SHOW TABLES LIKE '$table'");
            if ($result->num_rows === 0) {
                $tables_ok = false;
                $errors[] = "Table '$table' n'a pas été créée.";
            }
        }
        
        if ($tables_ok) {
            $success[] = 'Toutes les tables ont été créées avec succès.';
        }
        
        // Vérifier le dossier uploads
        $uploads_dir = __DIR__ . '/uploads/products';
        if (!is_dir($uploads_dir)) {
            if (mkdir($uploads_dir, 0777, true)) {
                $success[] = 'Dossier uploads créé.';
            } else {
                $errors[] = 'Impossible de créer le dossier uploads.';
            }
        } else {
            $success[] = 'Dossier uploads existe déjà.';
        }
        
        $conn->close();
    }
} catch (Exception $e) {
    $errors[] = 'Erreur: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation - Diexo E-commerce</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
        }
        .success {
            color: #27ae60;
            background: #d4edda;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .error {
            color: #e74c3c;
            background: #f8d7da;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .info {
            background: #d1ecf1;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
        .btn:hover {
            background: #2980b9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Installation de Diexo E-commerce</h1>
        
        <?php if (!empty($success)): ?>
            <h2>Succès:</h2>
            <?php foreach ($success as $msg): ?>
                <div class="success">✓ <?php echo htmlspecialchars($msg); ?></div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <h2>Erreurs:</h2>
            <?php foreach ($errors as $msg): ?>
                <div class="error">✗ <?php echo htmlspecialchars($msg); ?></div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <?php if (empty($errors)): ?>
            <div class="info">
                <h3>Installation terminée avec succès !</h3>
                <p><strong>Compte administrateur par défaut:</strong></p>
                <ul>
                    <li>Email: <code>admin@diexo.com</code></li>
                    <li>Mot de passe: <code>admin123</code></li>
                </ul>
                <p style="color: #e74c3c;"><strong>⚠️ IMPORTANT: Changez ce mot de passe après la première connexion !</strong></p>
                
                <p><strong>Prochaines étapes:</strong></p>
                <ol>
                    <li>Configurez votre numéro WhatsApp dans <code>config/config.php</code></li>
                    <li>Vérifiez l'URL du site dans <code>config/config.php</code></li>
                    <li>Supprimez ce fichier <code>install.php</code> pour des raisons de sécurité</li>
                    <li>Connectez-vous et commencez à ajouter des produits</li>
                </ol>
            </div>
            
            <a href="index.php" class="btn">Accéder au site</a>
            <a href="auth/login.php" class="btn">Se connecter</a>
        <?php else: ?>
            <div class="info">
                <p>Veuillez corriger les erreurs ci-dessus et réessayer.</p>
                <p>Assurez-vous que:</p>
                <ul>
                    <li>MySQL est démarré</li>
                    <li>Les identifiants dans <code>install.php</code> sont corrects</li>
                    <li>Le fichier <code>database/schema.sql</code> existe</li>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

